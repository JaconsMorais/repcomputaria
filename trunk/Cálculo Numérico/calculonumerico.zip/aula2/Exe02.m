function [ret,x0,str,ts,xts]=exe02(t,x,u,flag);
%EXE02	is the M-file description of the SIMULINK system named EXE02.
%	EXE02 has a the following characteristics:
%		0 continuous states
%		0 discrete states
%		0 outputs
%		0 inputs
%		does not have direct feedthrough
%		1 sample times
%
%	The block-diagram can be displayed by typing: EXE02.
%
%	SYS=EXE02(T,X,U,FLAG) returns depending on FLAG certain
%	system values given time point, T, current state vector, X,
%	and input vector, U.
%	FLAG is used to indicate the type of output to be returned in SYS.
%
%	Setting FLAG=1 causes EXE02 to return state derivatives, FLAG=2
%	discrete states, FLAG=3 system outputs and FLAG=4 next sample
%	time. For more information and other options see SFUNC.
%
%	Calling EXE02 with a FLAG of zero:
%	[SIZES]=EXE02([],[],[],0),  returns a vector, SIZES, which
%	contains the sizes of the state vector and other parameters.
%		SIZES(1) number of states
%		SIZES(2) number of discrete states
%		SIZES(3) number of outputs
%		SIZES(4) number of inputs
%		SIZES(5) number of roots (currently unsupported)
%		SIZES(6) direct feedthrough flag
%		SIZES(7) number of sample times
%
%	For the definition of other parameters in SIZES, see SFUNC.
%	See also, TRIM, LINMOD, LINSIM, EULER, RK23, RK45, ADAMS, GEAR.

% Note: This M-file is only used for saving graphical information;
%       after the model is loaded into memory an internal model
%       representation is used.

% the system will take on the name of this mfile:
sys = mfilename;
new_system(sys)
simver(1.3)
if (0 == (nargin + nargout))
     set_param(sys,'Location',[395,374,774,552])
     open_system(sys)
end;
set_param(sys,'algorithm',     'Euler')
set_param(sys,'Start time',    '0.0')
set_param(sys,'Stop time',     '999999')
set_param(sys,'Min step size', '0.1')
set_param(sys,'Max step size', '0.1')
set_param(sys,'Relative error','1e-3')
set_param(sys,'Return vars',   '')

add_block('built-in/Signal Generator',[sys,'/',['Signal',13,'Generator']])
set_param([sys,'/',['Signal',13,'Generator']],...
		'Peak','10.000000',...
		'Peak Range','50.000000',...
		'Freq','10.000000',...
		'Freq Range','50.000000',...
		'Wave','Sin',...
		'Units','Rads',...
		'position',[285,83,330,117])

add_block('built-in/Gain',[sys,'/','Gain'])
set_param([sys,'/','Gain'],...
		'Gain','2',...
		'position',[385,167,410,193])

add_block('built-in/Scope',[sys,'/','Scope'])
set_param([sys,'/','Scope'],...
		'Vgain','30.000000',...
		'Hgain','10.000000',...
		'Vmax','60.000000',...
		'Hmax','20.000000',...
		'Window',[385,-1,802,332])
open_system([sys,'/','Scope'])
set_param([sys,'/','Scope'],...
		'position',[460,85,490,115])

add_block('built-in/Scope',[sys,'/','Scope1'])
set_param([sys,'/','Scope1'],...
		'Vgain','30.000000',...
		'Hgain','10.000000',...
		'Vmax','60.000000',...
		'Hmax','20.000000',...
		'Window',[4,-1,379,332])
open_system([sys,'/','Scope1'])
set_param([sys,'/','Scope1'],...
		'position',[460,165,490,195])
add_line(sys,[335,100;455,100])
add_line(sys,[335,100;350,100;350,180;380,180])
add_line(sys,[415,180;455,180])

drawnow

% Return any arguments.
if (nargin | nargout)
	% Must use feval here to access system in memory
	if (nargin > 3)
		if (flag == 0)
			eval(['[ret,x0,str,ts,xts]=',sys,'(t,x,u,flag);'])
		else
			eval(['ret =', sys,'(t,x,u,flag);'])
		end
	else
		[ret,x0,str,ts,xts] = feval(sys);
	end
else
	drawnow % Flash up the model and execute load callback
end
