% Script para plotar as funcoes (no mesmo eixo):
%
%		y = exp(-x^2) * cos(20x)
%
echo off
clear
whitebg
clc

% valores de x
x=-2:0.1:2;

% calcula os valores de y de acordo com a formula
y = exp(-x.^2).* cos(x.* 20)

% plota o grafico
plot(x,y,'b')
hold on
% plota o grafico com "fplot"
fplot('exp(-x.^2).* cos(x.* 20)', [-2 2], 'r')
xlabel('X')
ylabel('Y')
title('Exercicio 6 - Usando plot & fplot')
hold off