% Script para plotar as funcoes (no mesmo eixo):
%
%		y1 = 3 * sin(pi * x)
%		y2 = exp(-0.2 * x)
%
echo off
clear
whitebg
clc

% valores de x
x=0:0.02:4;

% calcula os valores de y de acordo com a formula
y1 = 3 * sin(x.* pi)
y2 = exp(x.* (-0.2))

% plota o grafico y1
plot(x,y1,'b')
hold on
% plota o grafico y2
plot(x, y2, 'r')
xlabel('X')
ylabel('Y')
gtext('Pto. de Int.')
title('Exercicio 7')
hold off