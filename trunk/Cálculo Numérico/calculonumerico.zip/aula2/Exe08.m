% Script para plotar a funcao z:
%
%		z = (2 * x * y) / (x^2 + y^2)
%
echo off
clear
whitebg
clc

% plota o grafico z
[x, y] = meshgrid(1:0.1:3, 1:0.1:3)
% calcula os valores de z de acordo com a formula
z = (x.* y.* 2) / (x.^2 + y.^2)
mesh(x, y, z)
xlabel('X')
ylabel('Y')
title('Exercicio 8')