function [ret,x0,str,ts,xts]=eqdif(t,x,u,flag);
%EQDIF	is the M-file description of the SIMULINK system named EQDIF.
%	The block-diagram can be displayed by typing: EQDIF.
%
%	SYS=EQDIF(T,X,U,FLAG) returns depending on FLAG certain
%	system values given time point, T, current state vector, X,
%	and input vector, U.
%	FLAG is used to indicate the type of output to be returned in SYS.
%
%	Setting FLAG=1 causes EQDIF to return state derivatives, FLAG=2
%	discrete states, FLAG=3 system outputs and FLAG=4 next sample
%	time. For more information and other options see SFUNC.
%
%	Calling EQDIF with a FLAG of zero:
%	[SIZES]=EQDIF([],[],[],0),  returns a vector, SIZES, which
%	contains the sizes of the state vector and other parameters.
%		SIZES(1) number of states
%		SIZES(2) number of discrete states
%		SIZES(3) number of outputs
%		SIZES(4) number of inputs
%		SIZES(5) number of roots (currently unsupported)
%		SIZES(6) direct feedthrough flag
%		SIZES(7) number of sample times
%
%	For the definition of other parameters in SIZES, see SFUNC.
%	See also, TRIM, LINMOD, LINSIM, EULER, RK23, RK45, ADAMS, GEAR.

% Note: This M-file is only used for saving graphical information;
%       after the model is loaded into memory an internal model
%       representation is used.

% the system will take on the name of this mfile:
sys = mfilename;
new_system(sys)
simver(1.3)
if (0 == (nargin + nargout))
     set_param(sys,'Location',[200,201,713,501])
     open_system(sys)
end;
set_param(sys,'algorithm',     'RK-45')
set_param(sys,'Start time',    '0.0')
set_param(sys,'Stop time',     '99')
set_param(sys,'Min step size', '0.0001')
set_param(sys,'Max step size', '10')
set_param(sys,'Relative error','1e-3')
set_param(sys,'Return vars',   '9999')


%     Subsystem  'XY Graph'.

new_system([sys,'/','XY Graph'])
set_param([sys,'/','XY Graph'],'Location',[8,52,282,245])

add_block('built-in/Inport',[sys,'/','XY Graph/y'])
set_param([sys,'/','XY Graph/y'],...
		'Port','2',...
		'position',[10,100,30,120])

add_block('built-in/Inport',[sys,'/','XY Graph/x'])
set_param([sys,'/','XY Graph/x'],...
		'position',[10,30,30,50])

add_block('built-in/Mux',[sys,'/','XY Graph/Mux'])
set_param([sys,'/','XY Graph/Mux'],...
		'inputs','2',...
		'position',[100,61,130,94])

add_block('built-in/S-Function',[sys,'/',['XY Graph/S-function',13,'M-file which plots',13,'lines',13,'']])
set_param([sys,'/',['XY Graph/S-function',13,'M-file which plots',13,'lines',13,'']],...
		'function name','sfunxy',...
		'parameters','ax, st',...
		'position',[185,70,235,90])
add_line([sys,'/','XY Graph'],[35,110;70,110;70,85;95,85])
add_line([sys,'/','XY Graph'],[35,40;70,40;70,70;95,70])
add_line([sys,'/','XY Graph'],[135,80;180,80])
set_param([sys,'/','XY Graph'],...
		'Mask Display','plot(0,0,100,100,[12,91,91,12,12],[90,90,45,45,90],[51,57,65,75,80,79,75,67,60,54,51,48,42,34,28,27,31,42,51],[71,68,66,66,72,79,83,84,81,77,71,60,54,54,58,65,71,74,71])')
set_param([sys,'/','XY Graph'],...
		'Mask Type','XY scope.',...
		'Mask Dialogue','XY scope using MATLAB graph window.\nFirst input is used as time base.\nEnter plotting ranges.|x-min:|x-max:|y-min:|y-max:')
set_param([sys,'/','XY Graph'],...
		'Mask Translate','ax = [@1, @2, @3, @4];st=-1;',...
		'Mask Help','This block can be used to explore limit cycles. Look at the m-file sfunxy.m to see how it works.',...
		'Mask Entries','-10\/10\/-10\/10\/')


%     Finished composite block 'XY Graph'.

set_param([sys,'/','XY Graph'],...
		'position',[405,16,435,54])

add_block('built-in/Product',[sys,'/','Product'])
set_param([sys,'/','Product'],...
		'position',[110,128,140,152])

add_block('built-in/Fcn',[sys,'/','Fcn'])
set_param([sys,'/','Fcn'],...
		'Expr','1-u^u',...
		'position',[25,125,65,145])

add_block('built-in/Sum',[sys,'/','Sum'])
set_param([sys,'/','Sum'],...
		'inputs','-+',...
		'position',[185,125,205,145])

add_block('built-in/Integrator',[sys,'/','Integrator'])
set_param([sys,'/','Integrator'],...
		'Initial','1.5',...
		'position',[260,125,280,145])

add_block('built-in/Gain',[sys,'/','Gain'])
set_param([sys,'/','Gain'],...
		'position',[130,57,155,83])

add_block('built-in/To Workspace',[sys,'/','To Workspace'])
set_param([sys,'/','To Workspace'],...
		'mat-name','yout',...
		'position',[420,127,470,143])

add_block('built-in/To Workspace',[sys,'/',['To Workspace1',13,'']])
set_param([sys,'/',['To Workspace1',13,'']],...
		'mat-name','yout1',...
		'position',[420,182,470,198])

add_block('built-in/Integrator',[sys,'/','Integrator1'])
set_param([sys,'/','Integrator1'],...
		'Initial','1.5',...
		'position',[325,125,345,145])
add_line(sys,[70,135;105,135])
add_line(sys,[145,140;180,140])
add_line(sys,[210,135;255,135])
add_line(sys,[285,135;320,135])
add_line(sys,[350,135;415,135])
add_line(sys,[160,70;165,70;165,130;180,130])
add_line(sys,[350,135;370,135;370,40;5,40;5,135;20,135])
add_line(sys,[115,40;115,70;125,70])
add_line(sys,[285,135;285,25;400,25])
add_line(sys,[285,135;285,200;80,200;80,145;105,145])
add_line(sys,[350,135;350,45;400,45])
add_line(sys,[300,135;300,190;415,190])

drawnow

% Return any arguments.
if (nargin | nargout)
	% Must use feval here to access system in memory
	if (nargin > 3)
		if (flag == 0)
			eval(['[ret,x0,str,ts,xts]=',sys,'(t,x,u,flag);'])
		else
			eval(['ret =', sys,'(t,x,u,flag);'])
		end
	else
		[ret,x0,str,ts,xts] = feval(sys);
	end
else
	drawnow % Flash up the model and execute load callback
end
