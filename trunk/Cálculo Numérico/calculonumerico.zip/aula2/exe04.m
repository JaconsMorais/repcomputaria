% Script para plotar as funcoes:
%
%		y1 = (x^2)*cos(x)		(1)
%		y2 = (x^2)*sin(x)		(2)
%
echo off
clear
whitebg
clc

% valores de x
x=-2:0.1:2;

% calcula os valores de y1 e y2 de acordo com as formulas (1) e (2)
y1=(x.^2).*cos(x)
y2=(x.^2).*sin(x)

% plota o grafico de (1)
plot(x,y1,'b')
% espera por outra entrada ...
hold on
% plota o grafico de (2)
plot(x,y2,'r')
xlabel('X')
ylabel('Fun��es')
text(-1.5,1,'y1=(x.^2).*cos(x)')
text(-1,-2,'y2=(x.^2).*sin(x)')
title('Exercicio 4')
% mostra na mesma tela os dois graficos
hold off
