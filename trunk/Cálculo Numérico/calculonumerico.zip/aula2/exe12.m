% Exercicio 12
%
% L� um n�mero e imprime o arco seno
%

a = input('Digite o valor de a: ');
b = asin(a);
disp('Valor do arco seno de a .. ');
disp(b);