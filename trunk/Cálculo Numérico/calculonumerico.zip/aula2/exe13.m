% Exercicio 13
%
% Comparando os tempos de gera�ao da fun�ao y = sin(x) * x
%

x = 1 : 1 : 1000;
y = sin(x).* x;
tempo = cputime;

disp('1. maneira .. '); disp(cputime - tempo);

tempo = cputime;
for i = 1:1000, y(i) = sin(x(i)) * x(i); end

disp('2. maneira .. '); disp(cputime - tempo);