% Metodo Newton-Raphson 

% Algoritmo:              

% Seja a equa��o F(x) = 0

% 1)   Dados iniciais         x0  : aproxima��o inicial
%                             e   : precis�o

% 2)   Se  | F(x0) | < e  ent�o fa�a xbarra = x0. FIM.

% 3)   K = 1

% 4)   xk = xk-1 - F(x0) div F'(x0)	
     
% 5)   Se | F(xk) | < e    ou    Se  |xk - xk-1| < e   
%      ent�o  fa�a xbarra = xk. FIM.

% 6)   xk-1 = xk
     
% 7)   k  =  k + 1.  Volte para o passo 4.


function[res,it]=fnewton(func,dfunc,x,tol)
% x � um valor de partida, tol � a precisao desejada
it=0,x0=x
d=feval(func,x0)/feval(dfunc,x0);
while abs(d)>tol
      x1=x0-d;
      it=it+1;
      x0=x1;
      d=feval(func,x0)/feval(dfunc,x0);
end;
res=x0;