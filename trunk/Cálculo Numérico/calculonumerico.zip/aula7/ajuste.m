% Exemplo 

x=0:.25:6;
y=2+6*x.^2-x.^3;
xx=0:.02:6;
p=polyfit(x,y,3)
yy=polyval(p,xx);
plot(x,y,'om',xx,yy,'b')
axis([0 6 0 40])
xlabel('x'); ylabel('y');
