% Exemplo com adi��o de erros

x=0:.25:6;
y=2+6*x.^2-x.^3;  
 y=y+randn(size(x));
xx=0:.02:6;
p=polyfit(x,y,3)
yy=polyval(p,xx);
plot(x,y,'om',xx,yy,'b')
axis([0 6 0 40])
