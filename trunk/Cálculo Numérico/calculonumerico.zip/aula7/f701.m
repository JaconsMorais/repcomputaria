function[dof,z]=f701(x)
% x must be a row vector
[junk,n]=size(x);dof=3;z = zeros(dof,n);
z(1,:)=ones(1,n);z(2,:)=sin(ones(1,n)./(x+0.2));z(3,: ) =x;
