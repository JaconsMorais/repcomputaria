function c=fgenfit(func,x,y)
if any(size(x)~=size(y))
     disp('X and Y vextors must be same size')
end
n=length(y)
[p,junk]=feval(func,x(1));
A=zeros(p,p);b=zeros(p,1)
for i=1:n
[junk,f]=feval(func,x(i));
      for j=1:p
          for k=1:p;
              A(j,k)=A(j,k)+f(j)*f(k);
           end
           b(j)=b(j)+y(i)*f(j);
       end
end
c=A\b;
