% Programa da Aula 8

xs=[0:0.05:0.25 0.25:0.2:4.85];
us=sin(ones(size(xs))./(xs+0.2))+0.2* xs+0.06* randn(size(xs))
% save testdata xs xu
% load testdata
xx=0:.05:5;
c=fgenfit('f701',xs,us)
[junk,p] = feval('f701',xx);
yy = c'*p; plot(xs,us,'o',xx,yy,'b');
axis([0 5 -1.5 1.5])
xlabel('x');ylabel('y');

