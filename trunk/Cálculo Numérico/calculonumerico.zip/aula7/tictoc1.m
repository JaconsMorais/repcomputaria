% Exerc�cio 4

a = [4 -2 2; -2 10 -7; 2 -7 30]
b = [11 -15 29]'

tic
   x = a\b
toc 

tic 
   r = chol(a)
toc

tic 
   y = r\b
toc  