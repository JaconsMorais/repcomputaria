/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package areas;

/**
 *
 * @author Thales
 */
public interface AreaCalculavel {
    double calculaArea();
}
