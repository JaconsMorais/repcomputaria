/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package areas;

import java.io.*;

/**
 * Exercicio 2 (e parte do 3, que é só colocar um throws IOException em TODOS os códigos pedidos)
 * @author Thales
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int op;
        double num1,num2,res;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("1-Área do quadrado");
        System.out.println("2-Área do círculo");
        System.out.println("3-Área do retângulo");
        System.out.print("Opção: ");
        op = Integer.parseInt(reader.readLine());

        switch(op){
            case 1:
                 System.out.println("Digite o lado");
                 num1 = Double.parseDouble(reader.readLine());
                 Quadrado quad = new Quadrado(num1);
                 System.out.println("A área é " + quad.calculaArea());
                 break;

            case 2:
                 System.out.println("Digite o raio");
                 num1 = Double.parseDouble(reader.readLine());
                 Circulo circ = new Circulo(num1);
                 System.out.println("A área é " + circ.calculaArea());
                 break;

            case 3:
                 System.out.println("Digite a base");
                 num1 = Double.parseDouble(reader.readLine());
                 System.out.println("Digite a altura");
                 num2 = Double.parseDouble(reader.readLine());
                 Retangulo ret = new Retangulo(num1,num2);
                 System.out.println("A área é " + ret.calculaArea());
                 break;

            default:System.out.println("Opção inválida");
        }
    }

}
