/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package areas;

/**
 *
 * @author Thales
 */
public class Quadrado implements AreaCalculavel{

    private double l;

    public Quadrado(double l) {
        this.l = l;
    }

    public double calculaArea() {
        return l*l;
    }

}
