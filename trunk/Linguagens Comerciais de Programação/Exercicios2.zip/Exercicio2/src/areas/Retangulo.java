/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package areas;

/**
 *
 * @author Thales
 */
public class Retangulo implements AreaCalculavel{

    private double b,h;

    public Retangulo(double b, double h) {
        this.b = b;
        this.h = h;
    }

    public double calculaArea() {
        return b*h;
    }

}
