/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package calculadora;

/**
 *
 * @author user
 */
public class calculadora {

    public double getMult(double num1,double num2){
        return num1 * num2;
    }

    public double getSoma(double num1,double num2){
        return num1 + num2;
    }

    public double getSub(double num1,double num2){
        return num1 - num2;
    }

    public double getDiv(double num1,double num2){
        return num1 / num2;
    }

    public double getPorc(double num1,double p){
        return num1 * p / 100;
    }

}
