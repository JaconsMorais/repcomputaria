package exercicio1;

public class Animal extends FuncoesAnimais{

private String nome;
private String comida;
private int fome;

@Override
public void fazerBarulho(){
	System.out.println("barulho animal");
}

@Override
public void comer(){
	System.out.println("comer animal");
}

@Override
public void dormir(){
	System.out.println("dormir animal");
}

@Override
public void circular(){
	System.out.println("circular animal");
}

public String getComida() {
        return comida;
}

public void setComida(String comida) {
        this.comida = comida;
}

public int getFome() {
        return fome;
}

public void setFome(int fome) {
        this.fome = fome;
}

public String getNome() {
        return nome;
}

public void setNome(String nome) {
        this.nome = nome;
}

}