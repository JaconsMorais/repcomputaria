package exercicio1;

class Cachorro extends FuncoesAnimais{

@Override
public void fazerBarulho(){
	System.out.println("barulho cachorro canino animal");
}

@Override
public void comer(){
	System.out.println("comer cachorro canino animal");
}

    @Override
    public void dormir() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void circular() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}