package exercicio1;

class Felino extends FuncoesAnimais{

@Override
public void circular(){
	System.out.println("circular felino animal");
}

    @Override
    public void fazerBarulho() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void comer() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void dormir() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}