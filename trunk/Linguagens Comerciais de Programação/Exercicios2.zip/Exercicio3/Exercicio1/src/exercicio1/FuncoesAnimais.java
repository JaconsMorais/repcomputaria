/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package exercicio1;

/**
 *
 * @author user
 */
public abstract class FuncoesAnimais {
        public abstract void fazerBarulho();
        public abstract void comer();
        public abstract void dormir();
        public abstract void circular();
}
