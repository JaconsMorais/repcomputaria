package exercicio1;

class Gato extends FuncoesAnimais{
private String nome;

@Override
public void fazerBarulho(){
	System.out.println("barulho gato felino animal");
}

@Override
public void comer(){
	System.out.println("comer gato felino animal");
}

    @Override
    public void dormir() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void circular() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}