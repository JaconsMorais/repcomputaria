package exercicio1;

class Hipopotamo extends FuncoesAnimais{

@Override
public void fazerBarulho(){
	System.out.println("barulho hipopotamo animal");
}

@Override
public void comer(){
	System.out.println("comer hipopotamo animal");
}

    @Override
    public void dormir() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void circular() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}