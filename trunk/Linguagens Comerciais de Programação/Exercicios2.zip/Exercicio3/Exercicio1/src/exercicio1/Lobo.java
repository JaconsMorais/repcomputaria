package exercicio1;

class Lobo extends FuncoesAnimais{

@Override
public void fazerBarulho(){
	System.out.println("barulho lobo canino animal");
}

@Override
public void comer(){
	System.out.println("comer lobo canino animal");
}

    @Override
    public void dormir() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void circular() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}