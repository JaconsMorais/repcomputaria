/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package exercicio1;

/**
 * Exercício 1
 * @author user
 */

//coleta de lixo nas funções das classes
public class Main{

    /**
     *
     * @param args
     */
    public static void main(String[] args){

		Animal animal = new Animal();

		animal.setFome(5);
		animal.setComida("carne");
		animal.setNome("totó");

		animal.fazerBarulho();
		System.out.println(animal.getComida());

		System.out.println("*********************");
		Gato animal2 = new Gato();
		animal2.setNome("mimi");

		animal2.fazerBarulho();
		animal2.comer();

		System.out.println("*********************");
		Gato gato = new Gato();
		gato.setNome("Gato!!");
		gato.fazerBarulho();
		System.out.println(gato.getNome());
                System.out.println("*********************");
                teste();

	}


    public static void teste(){

		Gato gato = new Gato();
		Cachorro cachorro = new Cachorro();
		Felino felino = new Felino();
		Tigre tigre = new Tigre();
		Hipopotamo hipo = new Hipopotamo();

			gato.fazerBarulho();
			gato.comer();
			gato.circular();
			System.out.println("*********************");
                        cachorro.fazerBarulho();
			cachorro.comer();
			cachorro.circular();
			System.out.println("*********************");
                        felino.fazerBarulho();
			felino.comer();
			felino.circular();
			System.out.println("*********************");
                        tigre.fazerBarulho();
			tigre.comer();
			tigre.circular();
			System.out.println("*********************");
                        hipo.fazerBarulho();
			hipo.comer();
			hipo.circular();
			System.out.println("*********************");


	}

}

