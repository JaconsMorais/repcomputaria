package exercicio1;

class Tigre extends FuncoesAnimais{

@Override
public void fazerBarulho(){
	System.out.println("barulho tigre felino animal");
}

@Override
public void comer(){
	System.out.println("comer tigre felino animal");
}

    @Override
    public void dormir() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void circular() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}