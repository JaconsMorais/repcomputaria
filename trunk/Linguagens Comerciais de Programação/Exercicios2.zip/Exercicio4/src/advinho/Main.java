/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package advinho;

import java.io.*;

/**
 * Exercício 4
 * @author user
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int chute,tentativas,numero;
        advinhar adv;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String op = "S";

        while(op.equals("s") || op.equals("S")){
            numero = (int)(100*Math.random());
            chute = 101;
            tentativas = 0;
            adv = new advinhar(numero);

            while(!adv.advinha(chute) && tentativas < 20){
                if(tentativas != 0){
                    if(chute < numero) System.out.print("MAIOR! ");
                    if(chute > numero) System.out.print("menor! ");
                    System.out.println("Digite outro número");
                }else System.out.println("Digite um número");

                chute = Integer.parseInt(reader.readLine());

                tentativas++;
            }

            if(adv.advinha(chute)) System.out.println("Parabéns! Você acertou o número");
            else System.out.println("Infelizmente você não conseguiu. O número era "+ numero);
            System.out.println("Número de tentativas: "+tentativas);

            do{
                System.out.println("Deseja jogar novamente(s/n)? ");
                op = reader.readLine();

                if(!(op.equals("s") || op.equals("S") || op.equals("n") || op.equals("N")))
                    System.out.print("Opção inválida. ");
            }while(!(op.equals("s") || op.equals("S") || op.equals("n") || op.equals("N")));

        }

    }

}
