/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package advinho;

/**
 *
 * @author user
 */
public class advinhar {
    private int num;

    public advinhar(int num) {
        this.num = num;
    }

    public boolean advinha(int chute){

        if(chute == num) return true;
        else return false;

    }

}
