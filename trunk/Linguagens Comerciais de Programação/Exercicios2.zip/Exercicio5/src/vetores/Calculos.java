/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package vetores;

import java.util.ArrayList;

/**
 *
 * @author Thales
 */
public class Calculos {
    private int elementos;
    private ArrayList <Double> vet;
    private double soma = 0,maior,menor;
    private int i;

    public void MaiorMenor(){ //este é void, e depois são usados os getters
         maior = menor = vet.get(0); //ambos recebem o primeiro elemento
        for(i = 1;i < elementos; i++){
             if(vet.get(i) > maior) maior = vet.get(i);
             else if(vet.get(i) < menor) menor = vet.get(i);
        }
    }

    public Calculos(int elementos, ArrayList <Double> vet) {
        this.elementos = elementos;
        this.vet = vet;
        MaiorMenor();
    }

    public double getMaior() {
        return maior;
    }

    public double getMenor() {
        return menor;
    }

    public double Media(){
         for(i = 0;i < elementos; i++) soma += vet.get(i);
         return soma / elementos;
    }

}
