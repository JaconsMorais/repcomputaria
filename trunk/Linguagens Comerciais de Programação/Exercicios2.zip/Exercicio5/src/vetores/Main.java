/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package vetores;

import java.io.*;
import java.util.ArrayList;

/**
 * Exercício 5 - com erros
 * @author Thales
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        ArrayList <Double> vetor;
        int num,i;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Digite o número de elementos");
        num = Integer.parseInt(reader.readLine());
        vetor = new ArrayList(num);

        Vetor vet = new Vetor(num,vetor);

        vetor = vet.GeraVetor();

        Calculos calcular = new Calculos(num,vetor);

        System.out.print("Os elementos do vetor são ");
        for(i = 0;i < num;i++) System.out.print(vetor.get(i) + " ");

        System.out.println("");
        System.out.println("O maior número é " + calcular.getMaior());
        System.out.println("O menor número é " + calcular.getMenor());
        System.out.println("A média é " + calcular.Media());

    }

}
