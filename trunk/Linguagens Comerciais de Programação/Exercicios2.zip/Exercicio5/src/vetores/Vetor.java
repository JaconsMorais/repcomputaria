/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package vetores;
import java.util.ArrayList;

/**
 *
 * @author Thales
 */
public class Vetor {
     private int elementos;
     private ArrayList <Double> vet;
     private int i;

    public Vetor(int elementos, ArrayList <Double> vet) {
        this.elementos = elementos;
        this.vet = vet;
    }

    public ArrayList <Double> GeraVetor(){ //funciona como um "getter"
         for(i = 0;i < elementos; i++)
              vet.add(200*Math.random() - 100); //valor entre - 100 e 100
         return vet;
    }

}
