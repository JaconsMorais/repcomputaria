/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package exercicio6;

import java.io.*;

/**
 * Exercício 6
 * @author user
 */
public class Main {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        String frase,palavrasub,novafrase = "";
        String[] palavras;
        int i;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Digite uma frase");
        frase = reader.readLine();
        System.out.println("E a palavra substituta");
        palavrasub = reader.readLine();

        palavras = frase.split(" "); //divide a frase pelos espaços. Ou seja, em palavras

        palavras[i = (int)(palavras.length*Math.random())] = palavrasub; //pega uma palavra qualquer

        for(i = 0;i<palavras.length;i++){ //formação da frase nova
            novafrase += palavras[i];
            if(i < palavras.length - 1) novafrase += " ";
        }

        System.out.println("A frase antiga foi " + frase);
        System.out.println("A nova é " + novafrase);
    }

}
