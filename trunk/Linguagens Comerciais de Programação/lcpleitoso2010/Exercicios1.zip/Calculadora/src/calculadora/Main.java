/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package calculadora;

import java.io.*;

/**
 *
 * @author user
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double num1, num2;
        String op;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        calculadora Calc = new calculadora();
        
        try{
            System.out.println("Digite o numero 1:");
            num1 = Float.parseFloat(reader.readLine());
            System.out.println("Digite o numero 2:");
            num2 = Float.parseFloat(reader.readLine());
            System.out.println("x para multiplicação");
            System.out.println("+ para adição");
            System.out.println("- para subtração");
            System.out.println("/ para divisão");
            System.out.println("% para porcentagem");
            System.out.println("Digite a operação:");
            op = reader.readLine();

            if(op.equals("x")){
                System.out.println("O resultado é " + Calc.getMult(num1, num2));
            }else if(op.equals("+")){
                System.out.println("O resultado é " + Calc.getSoma(num1, num2));
            }else if(op.equals("-")){
                System.out.println("O resultado é " + Calc.getSub(num1, num2));
            }else if(op.equals("/")){
                System.out.println("O resultado é " + Calc.getDiv(num1, num2));
            }else if(op.equals("%")){
                System.out.println("O resultado é " + Calc.getPorc(num1, num2));
            }else{
                System.out.println("Opção inválida. Rode o programa novamente");
            }
        }catch (IOException e) {
            System.out.println("Erro: " + e);
        }
    }

}
