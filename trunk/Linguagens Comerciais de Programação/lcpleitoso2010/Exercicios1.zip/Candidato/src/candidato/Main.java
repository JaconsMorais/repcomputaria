/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package candidato;

/**
 *
 * @author aluno
 */

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        int i, vet, pop;

        pop = 1+(int)(Math.random()*10000);

        candidato[] candidatos = new candidato[3];

        candidatos[0] = new candidato("Zé da Silva");
        candidatos[1] = new candidato("Augusto da Rodinha");
        candidatos[2] = new candidato("Zéza Maria");

        for(i = 0;i< pop;i++){
            vet = (int)(Math.random()*3);
            candidatos[vet].incVoto();
        }

        System.out.println("Bem-vindos as eleições do municipio de Piraporanguinhas");
        System.out.println("População: " + pop);
        System.out.println("");

        for(i = 0;i< 3;i++)
            System.out.println("O candidato " + candidatos[i].getNome() + " teve " + candidatos[i].getVotos() + " votos.");

        if(candidatos[0].getVotos() > candidatos[1].getVotos()){
            if(candidatos[0].getVotos() > candidatos[2].getVotos()){
                System.out.println("O vencedor é o candidato " + candidatos[0].getNome() + ".");
            }else{
                System.out.println("O vencedor é o candidato " + candidatos[2].getNome() + ".");
            }
        }else{
            if(candidatos[1].getVotos() > candidatos[2].getVotos()){
                System.out.println("O vencedor é o candidato " + candidatos[1].getNome() + ".");
            }else{
                System.out.println("O vencedor é o candidato " + candidatos[2].getNome() + ".");
            }
        }

    }

}
