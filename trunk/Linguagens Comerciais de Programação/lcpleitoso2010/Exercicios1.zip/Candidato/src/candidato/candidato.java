package candidato;

public class candidato{

    private String nome;
    private int votos;

    public candidato(String nome) {
        this.nome = nome;
        this.votos = 0;
    }

    public void incVoto(){
        this.votos++;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getVotos() {
        return votos;
    }

    public void setVotos(int votos) {
        this.votos = votos;
    }



}