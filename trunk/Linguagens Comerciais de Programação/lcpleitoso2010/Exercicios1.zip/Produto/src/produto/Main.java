/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package produto;
import java.io.*;
import java.util.Date;

/**
 *
 * @author aluno
 */
public class Main {

    /**
     * @param args the command line arguments
     */

    public static int buscar(){
        int i;
                System.out.println("Digite o nome do produto");
                busca = reader.readLine();

                for(i = 0;i<3; i++){
                    if(produtos[i].getNome() == busca) break;
                }

                return i;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        int opcao,sair = 0,prod;
        String busca;
        Date data;

        produto[] produtos = new produto[3];

        produtos[0] = new produto();
        produtos[1] = new produto();
        produtos[2] = new produto();

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        try{
        while(sair != 1){
        System.out.println("1 - Consultar produto");
        System.out.println("2 - Modificar produto");
        System.out.println("3 - Sair");
        System.out.print("Opção: ");

        opcao = Integer.parseInt(reader.readLine());

        switch(opcao){
            case 1:
                prod = buscar();
                if(prod < 3){
                System.out.println(produtos[prod].getNome());
                System.out.println(produtos[prod].getPreco());
                System.out.println(produtos[prod].getEstoque());
                System.out.println(produtos[prod].getUltimaAquisicao());
                }else System.out.println("Produto não encontrado");
                break;
            case 2:
                prod = buscar();
                if(prod < 3){
                System.out.println("Digite o novo nome");
                produtos[prod].setNome(reader.readLine());
                System.out.println("Digite o novo preço");
                produtos[prod].setPreco(Float.parseFloat(reader.readLine()));
                System.out.println("Digite a nova quantidade em estoque");
                produtos[prod].setEstoque(Integer.parseInt(reader.readLine()));
                System.out.println("Digite a nova data da última aquisição");
                produtos[prod].setUltimaAquisicao(data.parse(reader.readLine()));
                }else System.out.println("Produto não encontrado");
                break;
            case 3: sair = 1;
                break;
            default: System.out.println("Opção invalida");
        }
        }
        }catch (IOException e) {
            System.out.println("Erro: " + e);
        }
    }

}
