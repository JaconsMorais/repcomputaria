/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package produto;
import java.util.Date;

/**
 *
 * @author aluno
 */
public class produto {
    private String nome;
    private float preco;
    private int estoque;
    private Date ultimaAquisicao;

    /*public produto(String nome, float preco, int estoque, Date ultimaAquisicao) {
        this.nome = nome;
        this.preco = preco;
        this.estoque = estoque;
        this.ultimaAquisicao = ultimaAquisicao;
    }*/


    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public Date getUltimaAquisicao() {
        return ultimaAquisicao;
    }

    public void setUltimaAquisicao(Date ultimaAquisicao) {
        this.ultimaAquisicao = ultimaAquisicao;
    }


}
