#ifndef PARSER_H
#include "PARSER_H"

void statement (void);
void pipeline (void);
void command (void);
void file (void);
void argument (void);
 
#endif

