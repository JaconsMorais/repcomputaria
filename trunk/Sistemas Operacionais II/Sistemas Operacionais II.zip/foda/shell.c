

        1 #include <stdio.h>

        2 #include <stdlib.h>

        3 #include <sys/types.h>

        4 

        5 #include "parser.h"

        6 #include "lexer.h"

        7 

        8 int main(int argc, char *argv[]){

        9 	Inicializar();

       10 	return 0;

       11 }


