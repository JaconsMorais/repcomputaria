#ifndef PARSER_H
#define PARSER_H

void statement (int argc, char **argv);
void pipeline(int p);
void command (void);
char *file(void);
char *argument(void);

#endif
