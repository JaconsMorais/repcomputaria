#include <stdio.h>
#include "util.h"

void hello(void)
{
	printf("Hello!\n");
}
