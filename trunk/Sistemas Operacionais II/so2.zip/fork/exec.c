#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[])
{

	printf("antes de exec()\n");
	execl("ls","ls",argv[1],NULL);
	printf("exec() feito!\n");

	return 0;

}
