#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	int pid;

	printf("Antes do fork\n");
	pid = fork();
	printf("Depois do fork\n");
	
	if (pid < 0) { //erro
		perror("fork");
		exit(1);
	}else if (pid > 0){ //processo pai
		printf("este é o processo pai falando...");
	}else{ //processo filho
		printf("este é o processo filho falando...");
	}

	return 0;
}
