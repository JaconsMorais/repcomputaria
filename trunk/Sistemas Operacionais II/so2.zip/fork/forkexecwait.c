#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
	int pid;

	printf("Antes do fork\n");
	pid = fork();
	printf("Depois do fork\n");
	
	if (pid < 0) { //erro
		perror("fork");
		exit(1);
	}else if (pid > 0){ //processo pai
		printf("antes de exec()\n");
		execl(argv[0],argv[0],NULL);
		printf("exec() feito!\n");
		printf("este é o processo pai falando...");
	}else{ //processo filho
		wait(NULL);
		printf("este é o processo filho falando...");
	}

	return 0;
}
