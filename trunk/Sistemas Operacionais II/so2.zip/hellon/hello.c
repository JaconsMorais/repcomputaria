#include <stdio.h>

int main(int argc,char *argv[])
{
	printf("Hello UNESP\n");
	printf("Hello UNESP!\n");
	return 0;
}
