#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>

int main(int argc, char *argv[]){

	int file = open("arq.txt",O_RDWR);;

	if(file<0){
		perror("open");
		exit(1);
	}

	int *data = mmap(NULL,sizeof(int),PROT_READ | PROT_WRITE,MAP_SHARED,file,0);

	if(data == NULL){
		perror("mmap");
		exit(1);
	}
	
	printf("O valor é %d. \n", *data);

	munmap(data,sizeof(int));
	close(file);

	return 0;

}
