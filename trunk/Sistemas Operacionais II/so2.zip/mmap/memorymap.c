#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char *argv[]){

	int file;
	int x = 123456;

	file = open("arq.txt",O_CREAT | O_RDWR,0666);
	if(file<0){
		perror("open");
		exit(1);
	}

	write(file,&x, sizeof(int));
	close(file);

	return 0;

}
